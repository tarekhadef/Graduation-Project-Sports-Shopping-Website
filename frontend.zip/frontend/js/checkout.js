let discount = 0;

function getToken() {
  return localStorage.getItem('token');
}

function calcTotals(shippingCost = 5, discountValue = 0) {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  const subtotal = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const tax = +(subtotal * 0.1).toFixed(2);
  const total = +(subtotal + tax + shippingCost - discountValue).toFixed(2);
  return { subtotal, tax, total, shippingCost, discount: discountValue };
}

function showSummary(totals) {
  document.getElementById('summary').innerHTML = `
    Subtotal: $${totals.subtotal.toFixed(2)}<br>
    Tax (10%): $${totals.tax.toFixed(2)}<br>
    Shipping: $${totals.shippingCost.toFixed(2)}<br>
    Discount: -$${totals.discount.toFixed(2)}<br>
    <strong>Total: $${totals.total.toFixed(2)}</strong>`;
}

function getShipCost() {
  return document.getElementById('shippingMethod').value === 'express' ? 15 : 5;
}

document.getElementById('applyCoupon').addEventListener('click', async () => {
  const code = document.getElementById('coupon').value.trim();
  if (!code) return;
  const res = await fetch(`http://localhost:5000/api/coupons/validate/${code}`);
  if (res.ok) {
    const data = await res.json();
    discount = calcTotals().subtotal * data.discountPercent / 100;
    alert(`Promo applied: ${data.discountPercent}% off`);
  } else {
    alert('Invalid promo code');
  }
  showSummary(calcTotals(getShipCost(), discount));
});

document.getElementById('shippingMethod').addEventListener('change', () => {
  showSummary(calcTotals(getShipCost(), discount));
});

document.addEventListener('DOMContentLoaded', async () => {
  showSummary(calcTotals(getShipCost(), discount));

  // ✅ FETCH AND SHOW AVAILABLE PROMO CODES
  try {
    const res = await fetch('http://localhost:5000/api/coupons');
    const promos = await res.json();
    const promoDiv = document.getElementById('availablePromos');

    if (promos.length === 0) {
      promoDiv.innerHTML = 'No promo codes available at this time.';
    } else {
      promoDiv.innerHTML = '<strong>Available Promo Codes:</strong><br>' +
        promos.map(p => `${p.code} (${p.discountPercent}% off)`).join('<br>');
    }
  } catch (err) {
    console.error('Error loading promo codes:', err);
    const promoDiv = document.getElementById('availablePromos');
    promoDiv.innerHTML = 'Error loading promo codes.';
  }
});

document.getElementById('checkoutForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  const token = getToken();
  if (!token) {
    alert('Please login to place order');
    return;
  }

  const shippingCost = getShipCost();
  const totals = calcTotals(shippingCost, discount);

  const orderBody = {
    items: cart.map(i => ({
      productId: i.id,
      qty: i.qty,
      price: i.price,
      name: i.name
    })),
    shipping: {
      address: document.getElementById('address').value,
      city: document.getElementById('city').value,
      country: document.getElementById('country').value,
      method: document.getElementById('shippingMethod').value,
      cost: shippingCost
    },
    tax: totals.tax,
    subtotal: totals.subtotal,
    total: totals.total,
    paymentMethod: document.getElementById('paymentMethod').value
  };

  const res = await fetch('http://localhost:5000/api/orders', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
    body: JSON.stringify(orderBody)
  });

  if (res.ok) {
    alert('Order placed!');
    localStorage.removeItem('cart');
    window.location.href = '/orders.html';
  } else {
    alert('Error placing order');
  }
});
