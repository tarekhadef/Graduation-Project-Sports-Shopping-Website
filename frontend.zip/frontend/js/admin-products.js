if (!localStorage.getItem('isAdmin')) {
  alert('Admins only');
  window.location.href = '/';
}

const token = localStorage.getItem('token');
const tbody = document.querySelector('#prodTable tbody');
const modal = new bootstrap.Modal(document.getElementById('prodModal'));
const promoModal = new bootstrap.Modal(document.getElementById('promoModal'));

// ============================
// PRODUCTS
// ============================

async function loadProducts() {
  const res = await fetch('http://localhost:5000/api/products');
  const prods = await res.json();
  tbody.innerHTML = ''; // clear old rows
  prods.forEach(p => {
    const imageTag = p.image ? `<img src="http://localhost:5000/uploads/${p.image}" width="50">` : '';
    tbody.innerHTML += `<tr>
      <td>${p.name}<br>${imageTag}</td>
      <td>$${p.price}</td>
      <td>${p.stock}</td>
      <td>
        <button class="btn btn-sm btn-primary" onclick="edit('${p._id}')">Edit</button>
        <button class="btn btn-sm btn-danger" onclick="delProd('${p._id}')">Del</button>
      </td>
    </tr>`;
  });
}

document.getElementById('newBtn').addEventListener('click', () => {
  document.getElementById('pid').value = '';
  ['pname', 'pdesc', 'pprice', 'pstock', 'pimg', 'pcat'].forEach(id => document.getElementById(id).value = '');
  modal.show();
});

window.edit = async id => {
  const p = await (await fetch('http://localhost:5000/api/products/' + id)).json();
  document.getElementById('pid').value = id;
  document.getElementById('pname').value = p.name;
  document.getElementById('pdesc').value = p.description;
  document.getElementById('pprice').value = p.price;
  document.getElementById('pstock').value = p.stock;
  document.getElementById('pcat').value = p.category || '';
  modal.show();
};

window.delProd = async id => {
  if (!confirm('Delete?')) return;
  await fetch('http://localhost:5000/api/products/' + id, {
    method: 'DELETE',
    headers: { Authorization: 'Bearer ' + token }
  });
  loadProducts();
};

document.getElementById('saveProd').addEventListener('click', async () => {
  const id = document.getElementById('pid').value;
  const formData = new FormData();
  formData.append('name', pname.value);
  formData.append('description', pdesc.value);
  formData.append('price', pprice.value);
  formData.append('stock', pstock.value);
  formData.append('category', pcat.value);
  if (pimg.files.length > 0) {
    formData.append('image', pimg.files[0]);
  }

  const method = id ? 'PUT' : 'POST';
  const url = 'http://localhost:5000/api/products' + (id ? '/' + id : '');

  await fetch(url, {
    method,
    headers: { Authorization: 'Bearer ' + token }, // no Content-Type → browser handles boundary
    body: formData
  });

  modal.hide();
  loadProducts();
});

// ============================
// PROMOS
// ============================

async function loadPromos() {
  const res = await fetch('http://localhost:5000/api/coupons', {
    headers: { Authorization: 'Bearer ' + token }
  });
  if (!res.ok) {
    alert('Failed to load promo codes');
    return;
  }
  const promos = await res.json();
  const promoTable = document.getElementById('promoTable');
  promoTable.innerHTML = ''; // clear
  promos.forEach(p => {
    const row = document.createElement('tr');
    row.innerHTML = `<td>${p.code}</td><td>${p.discountPercent}%</td>`;
    promoTable.appendChild(row);
  });
}

document.getElementById('newPromoBtn').addEventListener('click', () => {
  document.getElementById('promoCode').value = '';
  document.getElementById('promoDiscount').value = '';
  promoModal.show();
});

document.getElementById('savePromo').addEventListener('click', async () => {
  const code = document.getElementById('promoCode').value.trim();
  const discountPercent = parseInt(document.getElementById('promoDiscount').value);
  if (!code || isNaN(discountPercent)) {
    alert('Please fill code and discount %');
    return;
  }
  const res = await fetch('http://localhost:5000/api/coupons', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
    body: JSON.stringify({ code, discountPercent })
  });
  if (res.ok) {
    alert('Promo added!');
    promoModal.hide();
    loadPromos();
  } else {
    alert('Failed to add promo');
  }
});

document.addEventListener('DOMContentLoaded', () => {
  loadProducts();
  loadPromos();
});
