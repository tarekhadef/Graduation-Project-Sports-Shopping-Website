const form = document.getElementById('loginForm');

form.addEventListener('submit', async e => {
  e.preventDefault();

  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;

  // frontend-only admin shortcut
  if (email === 'admin' && password === 'admin') {
    localStorage.setItem('isAdmin', 'true');
    localStorage.setItem('username', 'Admin (bypass)');
    localStorage.removeItem('token'); // ensure no token sent
    window.location.href = '/admin/products.html';
    return;
  }

  try {
    const res = await fetch('http://localhost:5000/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    if (!res.ok) {
      alert('Login failed');
      return;
    }

    const data = await res.json();
    localStorage.setItem('token', data.token);
    localStorage.setItem('username', email);

    if (data.isAdmin) {
      localStorage.setItem('isAdmin', 'true');
      window.location.href = '/admin/products.html';
    } else {
      window.location.href = '/';
    }
  } catch (err) {
    console.error(err);
    alert('Error logging in');
  }
});
