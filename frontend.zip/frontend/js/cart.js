function render(){
  const cart=JSON.parse(localStorage.getItem('cart')||'[]');
  const div=document.getElementById('cartItems');
  div.innerHTML='';
  let subtotal=0;
  cart.forEach((it,idx)=>{
    subtotal+=it.price*it.qty;
    div.innerHTML+=`<div class="d-flex justify-content-between align-items-center border p-2 mb-2">
    <div>${it.name} (x${it.qty})</div>
    <div>$${(it.price*it.qty).toFixed(2)}</div>
    <button class="btn btn-sm btn-danger" onclick="removeItem(${idx})">x</button>
    </div>`;
  });
  document.getElementById('subtotal').innerText='Subtotal: $'+subtotal.toFixed(2);
}
function removeItem(i){
  const cart=JSON.parse(localStorage.getItem('cart'));
  cart.splice(i,1);
  localStorage.setItem('cart',JSON.stringify(cart));
  setCartBadge();
  render();
}
document.getElementById('checkoutBtn').addEventListener('click', ()=>{
  if(!JSON.parse(localStorage.getItem('cart')||'[]').length){ alert('Cart empty'); return; }
  if(!getToken() && !localStorage.getItem('isAdmin')){ window.location.href='/login.html'; return; }
  window.location.href='/checkout.html';
});
document.addEventListener('DOMContentLoaded', render);
