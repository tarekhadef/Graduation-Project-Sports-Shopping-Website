let productModal;

document.addEventListener('DOMContentLoaded', () => {
  const modalElem = document.getElementById('productModal');
  if (modalElem) {
    productModal = new bootstrap.Modal(modalElem);
  }

  const searchBox = document.getElementById('searchBox');
  const categoryFilter = document.getElementById('categoryFilter');

  if (searchBox) searchBox.addEventListener('input', () => load());
  if (categoryFilter) categoryFilter.addEventListener('change', () => load());

  if (searchBox && categoryFilter) load();
});

async function load() {
  const q = document.getElementById('searchBox').value.trim();
  const category = document.getElementById('categoryFilter').value;

  let query = [];
  if (q) query.push('search=' + encodeURIComponent(q));
  if (category) query.push('category=' + encodeURIComponent(category));

  const queryString = query.length ? '?' + query.join('&') : '';

  const res = await fetch('http://localhost:5000/api/products' + queryString);
  const prods = await res.json();
  const grid = document.getElementById('productGrid');
  grid.innerHTML = '';
  prods.forEach(p => {
    const col = document.createElement('div');
    col.className = 'col-sm-6 col-md-4 col-lg-3';
    const imageUrl = p.image ? `http://localhost:5000/uploads/${p.image}` : '';

    let stockMsg = '';
    if (p.stock === 0) {
      stockMsg = `<span class="text-danger">Out of stock</span>`;
    } else if (p.stock === 1) {
      stockMsg = `<span class="text-danger">Only 1 left!</span>`;
    } else {
      stockMsg = `<span>${p.stock} in stock</span>`;
    }

    const addBtn = p.stock > 0
      ? `<button class="btn btn-sm btn-primary w-100" onclick="addToCart('${p._id}', ${p.price}, '${p.name}')">Add to Cart</button>`
      : `<button class="btn btn-sm btn-secondary w-100" disabled>Out of Stock</button>`;

    col.innerHTML = `<div class="card h-100">
      <img src="${imageUrl}" class="card-img-top" style="object-fit:cover;height:180px">
      <div class="card-body d-flex flex-column">
        <h5 class="card-title">${p.name}</h5>
        <p class="card-text">$${p.price.toFixed(2)}</p>
        <p>${stockMsg}</p>
        <div class="mt-auto">
          <button class="btn btn-sm btn-info mb-2 w-100" onclick="viewProduct('${p._id}')">View Product</button>
          ${addBtn}
        </div>
      </div>
    </div>`;
    grid.appendChild(col);
  });
}

async function viewProduct(id) {
  const res = await fetch(`http://localhost:5000/api/products/${id}`);
  const p = await res.json();

  document.getElementById('modalTitle').innerText = p.name;
  document.getElementById('modalPrice').innerText = p.price.toFixed(2);
  document.getElementById('modalStock').innerHTML = p.stock === 0
    ? `<span class="text-danger">Out of stock</span>`
    : (p.stock === 1
      ? `<span class="text-danger">Only 1 left!</span>`
      : `${p.stock} in stock`);
  document.getElementById('modalRating').innerText = p.avgRating?.toFixed(1) || '0.0';

  const imageUrl = p.image ? `http://localhost:5000/uploads/${p.image}` : '';
  document.getElementById('modalImage').src = imageUrl;

  // fetch reviews
  const reviewsRes = await fetch(`http://localhost:5000/api/reviews/${id}`);
  if (!reviewsRes.ok) {
    alert('Unable to load reviews');
    document.getElementById('reviewList').innerHTML = '<li class="list-group-item text-danger">Reviews unavailable</li>';
    return;
  }
  const reviews = await reviewsRes.json();

  const reviewList = document.getElementById('reviewList');
  reviewList.innerHTML = '';
  reviews.forEach(r => {
    const li = document.createElement('li');
    li.className = 'list-group-item';
    li.innerText = `${r.rating}/5 - ${r.user?.name || 'Anonymous'}: ${r.text}`;
    reviewList.appendChild(li);
  });

  const submitReview = document.getElementById('submitReview');
  submitReview.onclick = async () => {
    const rating = parseInt(document.getElementById('reviewRating').value);
    const text = document.getElementById('reviewText').value.trim();
    const token = localStorage.getItem('token');

    const resp = await fetch(`http://localhost:5000/api/reviews/${id}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + token
      },
      body: JSON.stringify({ rating, text })
    });

    if (resp.ok) {
      alert('Review submitted!');
      viewProduct(id);  // reload modal
    } else {
      alert('Error submitting review');
    }
  };

  productModal.show();
}

function addToCart(id, price, name) {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  const item = cart.find(i => i.id === id);
  if (item) {
    item.qty += 1;
  } else {
    cart.push({ id, qty: 1, price, name });
  }
  localStorage.setItem('cart', JSON.stringify(cart));
  alert('Added to cart');
  setCartBadge();
}

window.viewProduct = viewProduct;
