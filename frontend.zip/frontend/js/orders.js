const token = localStorage.getItem('token');

async function loadOrders() {
  const res = await fetch('http://localhost:5000/api/orders', {
    headers: { Authorization: 'Bearer ' + token }
  });

  if (!res.ok) {
    alert('Failed to load orders');
    return;
  }

  const orders = await res.json();
  const table = document.getElementById('ordersTable');
  table.innerHTML = '';

  orders.forEach(o => {
    const tr = document.createElement('tr');

    tr.innerHTML = `
      <td>${o._id}</td>
      <td>
        ${o.refunded ? '<span class="text-danger">Refunded</span>' :
          o.received ? '<span class="text-success">Received</span>' :
          '<span class="text-warning">Pending</span>'}
      </td>
      <td>
        <input type="checkbox" ${o.received ? 'checked disabled' : ''} onchange="markReceived('${o._id}', this.checked)">
      </td>
      <td>
        ${o.received && !o.refunded ? `
          <select id="reason-${o._id}" class="form-select form-select-sm">
            <option value="Item missing">Item missing</option>
            <option value="Item broken">Item broken</option>
            <option value="Not same as image">Not same as image</option>
          </select>
          <button class="btn btn-sm btn-danger mt-1" onclick="requestRefund('${o._id}')">Request Refund</button>
        ` : o.refunded ? 'Refunded' : 'N/A'}
      </td>
    `;

    table.appendChild(tr);
  });
}

async function markReceived(id, checked) {
  if (!checked) return;
  const res = await fetch(`http://localhost:5000/api/orders/${id}/receive`, {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + token }
  });

  if (res.ok) {
    alert('Order marked as received');
    loadOrders();
  } else {
    alert('Error marking received');
  }
}

async function requestRefund(id) {
  const reason = document.getElementById(`reason-${id}`).value;
  const res = await fetch(`http://localhost:5000/api/orders/${id}/refund`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
    body: JSON.stringify({ reason })
  });

  if (res.ok) {
    alert('Refund requested');
    loadOrders();
  } else {
    alert('Error requesting refund');
  }
}

document.addEventListener('DOMContentLoaded', loadOrders);
window.markReceived = markReceived;
window.requestRefund = requestRefund;
