const token = localStorage.getItem('token');

async function load() {
  const res = await fetch('http://localhost:5000/api/orders', {
    headers: { Authorization: 'Bearer ' + token }
  });
  const orders = await res.json();
  const tbody = document.querySelector('#orderTable tbody');
  tbody.innerHTML = '';
  orders.forEach((o, i) => {
    const refundBtn = o.refunded
      ? '<span class="badge bg-success">Refunded</span>'
      : `<button class="btn btn-sm btn-danger refund" data-id="${o._id}">Refund</button>`;

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${i + 1}</td>
      <td>${o.user?.name || 'Guest'}</td>
      <td>$${o.total.toFixed(2)}</td>
      <td>
        <select data-id="${o._id}" class="form-select form-select-sm statusSel">
          ${['Pending', 'Processing', 'Shipped', 'Delivered', 'Refunded']
            .map(s => `<option ${o.status === s ? 'selected' : ''}>${s}</option>`)
            .join('')}
        </select>
      </td>
      <td>${new Date(o.createdAt).toLocaleString()}</td>
      <td>${o.refundReason || '-'}</td>
      <td>${refundBtn}</td>`;
    tbody.appendChild(tr);
  });
}

document.addEventListener('change', async e => {
  if (e.target.classList.contains('statusSel')) {
    const id = e.target.dataset.id;
    const status = e.target.value;
    await fetch(`http://localhost:5000/api/orders/${id}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
      body: JSON.stringify({ status })
    });
    load();
  }
});

document.addEventListener('click', async e => {
  if (e.target.classList.contains('refund')) {
    const id = e.target.dataset.id;
    if (!confirm('Approve refund for this order?')) return;
    await fetch(`http://localhost:5000/api/orders/${id}/refund-approve`, {
      method: 'POST',
      headers: { Authorization: 'Bearer ' + token }
    });
    load();
  }
});

document.addEventListener('DOMContentLoaded', load);