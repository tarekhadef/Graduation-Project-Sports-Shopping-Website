document.addEventListener('DOMContentLoaded', async () => {
  const token = localStorage.getItem('token');
  if (!token) {
    alert('Please login first');
    window.location.href = '/login.html';
    return;
  }

  const res = await fetch('http://localhost:5000/api/auth/me', {
    headers: { Authorization: 'Bearer ' + token }
  });

  const user = await res.json();
  document.getElementById('username').value = user.name;
  document.getElementById('currentProfilePic').src = user.profilePic ? `http://localhost:5000/uploads/${user.profilePic}` : '/default-avatar.png';
  document.getElementById('navProfilePic').src = user.profilePic ? `http://localhost:5000/uploads/${user.profilePic}` : '/default-avatar.png';

  document.getElementById('saveProfile').addEventListener('click', async () => {
    const formData = new FormData();
    formData.append('name', document.getElementById('username').value);
    const file = document.getElementById('newProfilePic').files[0];
    if (file) formData.append('profilePic', file);

    const updateRes = await fetch('http://localhost:5000/api/auth/profile', {
      method: 'PUT',
      headers: { Authorization: 'Bearer ' + token },
      body: formData
    });

    if (updateRes.ok) {
      alert('Profile updated!');
      location.reload();
    } else {
      alert('Update failed');
    }
  });
});
