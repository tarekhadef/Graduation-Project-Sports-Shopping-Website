document.getElementById('registerForm').addEventListener('submit', async e=>{
  e.preventDefault();
  const name=document.getElementById('name').value.trim();
  const email=document.getElementById('email').value.trim();
  const password=document.getElementById('password').value;
  try{
    const res=await fetch('http://localhost:5000/api/auth/register',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({name,email,password})
    });
    if(res.ok){
      alert('Registered, please login');
      window.location.href='/login.html';
    }else{
      alert('Register failed');
    }
  }catch(err){console.error(err);}
});
