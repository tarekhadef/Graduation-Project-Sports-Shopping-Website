function getToken() {
  return localStorage.getItem('token');
}

function setCartBadge() {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  const cartCount = document.getElementById('cartCount');
  if (cartCount) {
    cartCount.innerText = cart.reduce((a, b) => a + b.qty, 0);
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  setCartBadge();

  const loginLink = document.getElementById('loginLink');
  const profilePicElem = document.getElementById('navProfilePic');
  const myOrdersLink = document.getElementById('myOrdersLink');
  const adminNavItem = document.getElementById('adminNavItem');
  const cartLink = document.querySelector('a[href="/cart.html"]');

  const token = getToken();
  const username = localStorage.getItem('username');
  const isAdmin = localStorage.getItem('isAdmin');

  // ✅ Hide cart link if admin
  if (isAdmin && cartLink) {
    cartLink.style.display = 'none';
  }

  // ✅ Hide My Orders if not logged in
  if (!token && myOrdersLink) {
    myOrdersLink.style.display = 'none';
  }

  // ✅ SHOW ADMIN NAVBAR LINK
  if (isAdmin && adminNavItem) {
    adminNavItem.style.display = 'block';
  }

  if (loginLink) {
    if (token && username) {
      loginLink.textContent = `Logged in as ${username}`;
      loginLink.href = '#';

      try {
        const res = await fetch('http://localhost:5000/api/auth/me', {
          headers: { Authorization: 'Bearer ' + token }
        });
        if (res.ok) {
          const user = await res.json();
          if (profilePicElem) {
            profilePicElem.src = user.profilePic
              ? `http://localhost:5000/uploads/${user.profilePic}`
              : '/default-avatar.png';
          }
        }
      } catch (err) {
        console.error('Error fetching profile info:', err);
      }

      const logoutBtn = document.createElement('a');
      logoutBtn.textContent = 'Logout';
      logoutBtn.href = '#';
      logoutBtn.classList.add('nav-link');
      logoutBtn.addEventListener('click', () => {
        localStorage.removeItem('token');
        localStorage.removeItem('username');
        localStorage.removeItem('isAdmin');
        window.location.href = '/login.html';
      });

      loginLink.parentElement.after(logoutBtn);
    } else {
      loginLink.textContent = 'Login';
      loginLink.href = '/login.html';
      if (profilePicElem) profilePicElem.src = '/default-avatar.png';
    }
  }
});
