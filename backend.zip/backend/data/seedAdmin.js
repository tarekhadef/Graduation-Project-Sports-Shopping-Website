require('dotenv').config();
const bcrypt = require('bcrypt');
const mongoose = require('mongoose');
const User = require('../models/User');

(async ()=>{
  try{
    await mongoose.connect(process.env.MONGO_URI);
    const email = 'admin@shop.com';
    if(await User.findOne({ email })){
      console.log('admin already exists');
      process.exit(0);
    }
    const hash = await bcrypt.hash('admin', 10);
    await User.create({ name:'Admin', email, password:hash, isAdmin:true });
    console.log('seeded admin');
    process.exit(0);
  }catch(err){
    console.error(err);
    process.exit(1);
  }
})();
