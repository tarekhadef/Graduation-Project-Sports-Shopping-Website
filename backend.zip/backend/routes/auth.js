const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { protect } = require('../middleware/auth');
const multer = require('multer');
const path = require('path');

const router = express.Router();

// Multer for profile pic
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname))
});
const upload = multer({ storage });

// ✅ REGISTER
router.post('/register', async (req, res) => {
  const { name, email, password } = req.body;
  if (await User.findOne({ email })) return res.status(400).json({ message: 'Email exists' });
  const hash = await bcrypt.hash(password, 10);
  const user = await User.create({ name, email, password: hash });
  const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '2h' });
  res.status(201).json({ token, isAdmin: user.isAdmin });
});

// ✅ LOGIN
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (user && await user.matchPassword(password)) {
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '2h' });
    return res.json({ token, isAdmin: user.isAdmin });
  }
  res.status(401).json({ message: 'Invalid credentials' });
});

// ✅ GET current user info
router.get('/me', protect, async (req, res) => {
  const user = await User.findById(req.user._id);
  res.json(user);
});

// ✅ UPDATE profile
router.put('/profile', protect, upload.single('profilePic'), async (req, res) => {
  const update = { name: req.body.name };
  if (req.file) update.profilePic = req.file.filename;
  const user = await User.findByIdAndUpdate(req.user._id, update, { new: true });
  res.json(user);
});

module.exports = router;
