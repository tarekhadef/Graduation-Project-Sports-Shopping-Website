
const express = require('express');
const router = express.Router();

// simple shipping & tax calculation
// POST { country, items:[{price,qty}], method }
router.post('/calc', (req, res) => {
  const { country, items, method='standard' } = req.body;
  const subtotal = items.reduce((s,i)=>s + i.price * i.qty,0);
  const shipping = method==='express'? 15 : country.toLowerCase()==='egypt'? 5 : 20;
  const taxRate = country.toLowerCase()==='egypt'? 0.14 : 0.1;
  const tax = +(subtotal * taxRate).toFixed(2);
  res.json({ shipping, tax, subtotal });
});

module.exports = router;
