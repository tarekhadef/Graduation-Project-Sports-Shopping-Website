const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const Product = require('../models/Product');
const { protect } = require('../middleware/auth');

// ✅ PLACE ORDER
router.post('/', protect, async (req, res) => {
  const { items, shipping, tax, subtotal, total, paymentMethod } = req.body;

  const order = await Order.create({
    user: req.user._id,
    items,
    shipping,
    tax,
    subtotal,
    total,
    paymentMethod,
    status: 'Processing'
  });

  // ✅ reduce stock
  for (const item of items) {
    const product = await Product.findById(item.productId);
    if (product) {
      product.stock = Math.max(0, product.stock - item.qty);
      await product.save();
    }
  }

  res.status(201).json(order);
});

// ✅ GET ALL ORDERS
router.get('/', protect, async (req, res) => {
  const filter = req.user.role === 'admin' ? {} : { user: req.user._id };
  const orders = await Order.find(filter).populate('user', 'name email').sort('-createdAt');
  res.json(orders);
});

// ✅ MARK RECEIVED
router.post('/:id/receive', protect, async (req, res) => {
  const order = await Order.findById(req.params.id);
  if (!order) return res.status(404).json({ message: 'Not found' });

  if (order.user.toString() !== req.user._id.toString()) return res.status(403).json({ message: 'Unauthorized' });

  order.received = true;
  order.status = 'Received';
  await order.save();
  res.json(order);
});

// ✅ REQUEST REFUND
router.post('/:id/refund', protect, async (req, res) => {
  const order = await Order.findById(req.params.id);
  if (!order) return res.status(404).json({ message: 'Not found' });

  if (order.user.toString() !== req.user._id.toString()) return res.status(403).json({ message: 'Unauthorized' });

  if (!order.received) return res.status(400).json({ message: 'Cannot refund unreceived order' });

  order.refundReason = req.body.reason;
  order.status = 'Refund Requested';
  await order.save();

  res.json(order);
});

// ✅ APPROVE REFUND (admin only)
router.post('/:id/refund-approve', protect, async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ message: 'Admin only' });

  const order = await Order.findById(req.params.id);
  if (!order) return res.status(404).json({ message: 'Order not found' });

  order.status = 'Refund Approved';
  order.refunded = true;
  await order.save();

  res.json(order);
});

// ✅ REJECT REFUND (admin only)
router.post('/:id/refund-reject', protect, async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ message: 'Admin only' });

  const order = await Order.findById(req.params.id);
  if (!order) return res.status(404).json({ message: 'Order not found' });

  order.status = 'Refund Rejected';
  await order.save();

  res.json(order);
});

module.exports = router;
