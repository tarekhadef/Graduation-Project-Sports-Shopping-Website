const express = require('express');
const router = express.Router();
const Coupon = require('../models/Coupon');
const { protect, adminOnly } = require('../middleware/auth');

// ✅ create promo code
router.post('/', protect, adminOnly, async (req, res) => {
  const { code, discountPercent, expiresAt } = req.body;
  const coupon = await Coupon.create({ code, discountPercent, expiresAt });
  res.status(201).json(coupon);
});

// ✅ get all promo codes
router.get('/', async (req, res) => {
  const codes = await Coupon.find();
  res.json(codes);
});

// ✅ validate single code
router.get('/validate/:code', async (req, res) => {
  const coupon = await Coupon.findOne({ code: req.params.code });
  if (!coupon) return res.status(404).json({ message: 'Invalid code' });
  if (coupon.expiresAt && new Date() > coupon.expiresAt) return res.status(400).json({ message: 'Expired' });
  res.json(coupon);
});

// ✅ delete promo
router.delete('/:id', protect, adminOnly, async (req, res) => {
  await Coupon.findByIdAndDelete(req.params.id);
  res.json({ message: 'Deleted' });
});

module.exports = router;
