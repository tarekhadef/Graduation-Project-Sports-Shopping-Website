const express = require('express');
const router = express.Router();
const Review = require('../models/Review');
const Product = require('../models/Product');
const { protect } = require('../middleware/auth');

// ✅ GET reviews → PUBLIC
router.get('/:productId', async (req, res) => {
  const reviews = await Review.find({ product: req.params.productId }).populate('user', 'name');
  res.json(reviews);
});

// ✅ POST review → needs login
router.post('/:productId', protect, async (req, res) => {
  const { rating, text } = req.body;
  const review = await Review.create({
    product: req.params.productId,
    user: req.user._id,
    rating,
    text
  });

  const product = await Product.findById(req.params.productId);
  if (!product) return res.status(404).json({ message: 'Product not found' });

  product.numReviews += 1;
  product.avgRating = ((product.avgRating * (product.numReviews - 1)) + rating) / product.numReviews;
  await product.save();

  res.status(201).json(review);
});

module.exports = router;
