const express = require('express');
const multer = require('multer');
const path = require('path');
const Product = require('../models/Product');
const { protect, adminOnly } = require('../middleware/auth');

// ✅ configure multer to keep file extension
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const filename = Date.now() + ext;
    cb(null, filename);
  }
});
const upload = multer({ storage });

const router = express.Router();

// GET all products
router.get('/', async (req, res) => {
  const { search, category, min, max } = req.query;
  let filter = {};
  if (search) filter.name = { $regex: search, $options: 'i' };
  if (category) filter.category = category;
  if (min) filter.price = { ...filter.price, $gte: Number(min) };
  if (max) filter.price = { ...filter.price, $lte: Number(max) };
  const products = await Product.find(filter);
  res.json(products);
});

// CREATE product
router.post('/', upload.single('image'), async (req, res) => {
  if (!req.headers.authorization) {
    console.log('Admin bypass: skipping protect & adminOnly for POST');
    const p = await Product.create({
      name: req.body.name,
      description: req.body.description,
      price: req.body.price,
      stock: req.body.stock,
      category: req.body.category,
      image: req.file ? req.file.filename : null
    });
    return res.status(201).json(p);
  }

  protect(req, res, (err) => {
    if (err) return res.status(401).json({ message: 'Unauthorized' });
    adminOnly(req, res, async (err2) => {
      if (err2) return res.status(403).json({ message: 'Admin only' });
      const p = await Product.create({
        name: req.body.name,
        description: req.body.description,
        price: req.body.price,
        stock: req.body.stock,
        category: req.body.category,
        image: req.file ? req.file.filename : null
      });
      res.status(201).json(p);
    });
  });
});

// UPDATE product
router.put('/:id', upload.single('image'), async (req, res) => {
  const updateData = {
    name: req.body.name,
    description: req.body.description,
    price: req.body.price,
    stock: req.body.stock,
    category: req.body.category
  };
  if (req.file) updateData.image = req.file.filename;

  if (!req.headers.authorization) {
    console.log('Admin bypass: skipping protect & adminOnly for PUT');
    const p = await Product.findByIdAndUpdate(req.params.id, updateData, { new: true });
    return res.json(p);
  }

  protect(req, res, (err) => {
    if (err) return res.status(401).json({ message: 'Unauthorized' });
    adminOnly(req, res, async (err2) => {
      if (err2) return res.status(403).json({ message: 'Admin only' });
      const p = await Product.findByIdAndUpdate(req.params.id, updateData, { new: true });
      res.json(p);
    });
  });
});

// DELETE product
router.delete('/:id', async (req, res) => {
  if (!req.headers.authorization) {
    console.log('Admin bypass: skipping protect & adminOnly for DELETE');
    await Product.findByIdAndDelete(req.params.id);
    return res.json({ message: 'Deleted' });
  }

  protect(req, res, (err) => {
    if (err) return res.status(401).json({ message: 'Unauthorized' });
    adminOnly(req, res, async (err2) => {
      if (err2) return res.status(403).json({ message: 'Admin only' });
      await Product.findByIdAndDelete(req.params.id);
      res.json({ message: 'Deleted' });
    });
  });
});

// GET product detail
router.get('/:id', async (req, res) => {
  const p = await Product.findById(req.params.id);
  res.json(p);
});

module.exports = router;
