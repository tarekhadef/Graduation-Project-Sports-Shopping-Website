require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const path = require('path');

const authRoutes = require('./routes/auth');
const productRoutes = require('./routes/products');
const orderRoutes = require('./routes/orders');
const reviewRoutes = require('./routes/reviews');
const couponRoutes = require('./routes/coupons');
const shippingRoutes = require('./routes/shipping'); // ✅ optional if exists

const { protect, adminOnly } = require('./middleware/auth');

const app = express();
app.use(cors());
app.use(express.json());

// ✅ serve uploads folder
const uploadsPath = path.join(__dirname, 'uploads');
console.log('STATIC PATH:', uploadsPath);
app.use('/uploads', express.static(uploadsPath));

// ✅ connect DB
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('MongoDB connected'))
  .catch(err => { console.error(err); process.exit(1); });

// ✅ routes
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/orders', protect, orderRoutes);
app.use('/api/reviews', reviewRoutes);
app.use('/api/coupons', couponRoutes);
if (shippingRoutes) app.use('/api/shipping', shippingRoutes);

app.get('/', (req, res) => res.send('Sports Shop API running'));

const port = process.env.PORT || 5000;
app.listen(port, () => console.log(`Server running on port ${port}`));