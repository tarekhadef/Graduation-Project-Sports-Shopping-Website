const mongoose = require('mongoose');

const OrderSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  items: [{
    productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
    qty: Number,
    price: Number,
    name: String
  }],
  shipping: {
    address: String,
    city: String,
    country: String,
    method: String,
    cost: Number
  },
  tax: Number,
  subtotal: Number,
  total: Number,
  paymentMethod: String,
  received: { type: Boolean, default: false },
  refunded: { type: Boolean, default: false },
  refundReason: String,
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Order', OrderSchema);
