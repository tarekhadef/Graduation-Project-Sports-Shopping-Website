const mongoose = require('mongoose');

const ProductSchema = new mongoose.Schema({
  name: String,
  description: String,
  price: Number,
  stock: Number,
  image: String,
  category: String,
  avgRating: { type: Number, default: 0 },
  numReviews: { type: Number, default: 0 },
  reviews: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Review' }]  // ✅ ADD THIS
}, { timestamps: true });

module.exports = mongoose.model('Product', ProductSchema);
