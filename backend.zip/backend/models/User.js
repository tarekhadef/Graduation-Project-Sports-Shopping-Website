const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

const UserSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true },
  password: String,
  isAdmin: { type: Boolean, default: false },
  profilePic: String
}, { timestamps: true });

UserSchema.methods.matchPassword = async function (plain) {
  return await bcrypt.compare(plain, this.password);
};

module.exports = mongoose.model('User', UserSchema);
